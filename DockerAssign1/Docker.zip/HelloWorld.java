class HelloWorld{
	public static void main(String[] args) {
		System.out.println("Hello World");
		System.out.println("D2 developer");
		System.out.println("Hello World");
		System.out.println("By D1 developer");
		System.out.println("This is from CDAC ACTS");
		System.out.println("We are in DAC");
	}
}
