//package pompages;
//
//import org.openqa.selenium.By;
//import org.openqa.selenium.NoSuchElementException;
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebElement;
//import org.openqa.selenium.support.FindBy;
//import org.openqa.selenium.support.PageFactory;
//
//public class PlanPage {
//
//    WebDriver driver;
//
//    public PlanPage(WebDriver driver){
//        this.driver = driver;
//        PageFactory.initElements(driver, this);
//    }
//
//    @FindBy(xpath = "//div[.='Sign Up']/div")
//    private WebElement signUp;
//
//    @FindBy(xpath = "//div[.='Books at a time']//div[@class='cursor-pointer']/following-sibling::div")
//    private WebElement plusBooks;
//
//    @FindBy(xpath = "//div[.='Books at a time']//input[@value='2']")
//    private WebElement getNumOfBooks;
//
//    @FindBy(xpath = "//div[.='Number of Months']//div[@class='cursor-pointer']/preceding-sibling::div")
//    private WebElement minusNumOfMonths;
//
//    @FindBy(xpath = "//div[.='Number of Months']//div[@class='cursor-pointer']/following-sibling::div")
//    private WebElement plusNumOfMonths;
//
//    @FindBy(xpath = "//div[.='Net Payable Amount']/following-sibling::div")
//    private WebElement npa;
//
//    public WebElement getSignUp() {
//        return signUp;
//    }
//
//    public WebElement getPlusBooks() {
//        return plusBooks;
//    }
//
//    public WebElement getMinusNumOfMonths() {
//        return minusNumOfMonths;
//    }
//
//    public WebElement getPlusNumOfMonths() {
//        return plusNumOfMonths;
//    }
//
//    public WebElement getNpa() {
//        return npa;
//    }
//
//    public void geNBooks(int myval) {
//        if (myval <2){
//            System.out.println("Minimum two books have to be selected. Proceeding with two books.");
//        }
//        else if (myval>2){
//            for (int i = 2; i < myval; i++) {
//                plusBooks.click();
//            }
//        }
//
//    }
//}
