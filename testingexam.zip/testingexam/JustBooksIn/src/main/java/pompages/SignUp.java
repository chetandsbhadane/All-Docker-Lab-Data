//package pompages;
//
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebElement;
//import org.openqa.selenium.support.FindBy;
//import org.openqa.selenium.support.PageFactory;
//
//public class SignUp {
//
//    WebDriver driver;
//
//    public SignUp(WebDriver driver){
//        this.driver = driver;
//        PageFactory.initElements(driver, this);
//    }
//
//    @FindBy(xpath = "//input[@placeholder='Your First Name']")
//    private WebElement firstName;
//
//    @FindBy(xpath = "//input[@placeholder='Your Last Name']")
//    private WebElement lastName;
//
//    @FindBy(xpath = "//label[.='Mobile Number (+91)']/ancestor::div[@class='mt-4']//input")
//    private WebElement mobileNumber;
//
//    @FindBy(xpath = "//label[.='Email']/ancestor::div[@class='mt-4']//input")
//    private WebElement email;
//
//    @FindBy(xpath = "//label[.='Pincode']/ancestor::div[@class='mt-4']//input")
//    private WebElement pincode;
//
//    @FindBy(xpath = "//div[.='Next']")
//    private WebElement nextButton;
//
//    public WebElement getFirstName() {
//        return firstName; 
//    }
//
//    public WebElement getLastName() {
//        return lastName;
//    }
//
//    public WebElement getMobileNumber() {
//        return mobileNumber;
//    }
//
//    public WebElement getEmail() {
//        return email;
//    }
//
//    public WebElement getPincode() {
//        return pincode;
//    }
//
//    public WebElement getNextButton() {
//        return nextButton;
//    }
//}
