//package justbookstest;
//
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.chrome.ChromeDriver;
//import org.testng.annotations.AfterTest;
//import org.testng.annotations.BeforeTest;
//import org.testng.annotations.Test;
//import org.testng.asserts.SoftAssert;
//import pompages.PlanPage;
//import pompages.SignUp;
//
//import java.io.FileInputStream;
//import java.io.IOException;
//import java.util.Properties;
//import java.util.concurrent.TimeUnit;
//
//public class JustBooksSigningUp {
//
//	private WebDriver driver;
//	private SoftAssert sa = new SoftAssert();
//
//	@BeforeTest
//	public void ReadInputData() {
//		//WebDriverManager.chromedriver().setup();
//		driver = new ChromeDriver();
//	}
//	
//	/**
//	 * @author :
//	 * Description :
//	 * Last Modified :
//	 * Modified By :
//	 * Comments : 
//	 */
//	@Test(priority = 1)
//	public void signUp() throws IOException, InterruptedException {
//		Properties prop = new Properties();
//		FileInputStream fis = new FileInputStream("./src/test/resources/config.properties");
//		prop.load(fis);
//
//		driver.manage().timeouts().implicitlyWait(20l, TimeUnit.SECONDS);
//		driver.manage().window().maximize();
//
//		System.out.println(prop.getProperty("URL"));
//		driver.get(prop.getProperty("URL"));
//
//		PlanPage planPage = new PlanPage(driver);
//		planPage.geNBooks(Integer.parseInt(prop.getProperty("booksatatime")));
//		planPage.getPlusNumOfMonths().click();
//		Thread.sleep(7000);
//		System.out.println(planPage.getNpa().getText());
//		planPage.getSignUp().click();
//
//		sa.assertEquals(driver.getCurrentUrl(), prop.getProperty("signup_url"));
//	
//		SignUp signUp = new SignUp(driver);
//		signUp.getFirstName().sendKeys(prop.getProperty("firstName"));
//		signUp.getLastName().sendKeys(prop.getProperty("lastName"));
//		signUp.getMobileNumber().sendKeys(prop.getProperty("mobileNumber"));
//		signUp.getEmail().sendKeys(prop.getProperty("email"));
//		signUp.getPincode().sendKeys(prop.getProperty("pincode"));
//		signUp.getNextButton().click();
//	}
//
//	@AfterTest
//	public void tearDown(){
//		driver.quit();
//	}
//	
//}
