package demo.test;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class DemoTest {

	private WebDriver driver;
	private SoftAssert sa = new SoftAssert();

	@BeforeMethod
	public void ReadInputData() {
		driver = new ChromeDriver();
	}

	@Test(priority = 1)
	public void App() throws IOException, InterruptedException {
		Properties prop = new Properties();
		FileInputStream fis = new FileInputStream("./src/test/resources/config.properties");
		prop.load(fis);

		driver.manage().timeouts().implicitlyWait(20l, TimeUnit.SECONDS);
		driver.manage().window().maximize();

		System.out.println(prop.getProperty("https://artoftesting.com/samplesiteforselenium"));
		driver.get(prop.getProperty("https://artoftesting.com/samplesiteforselenium"));
		

	}

//	public static void main(String[] args) {
//		WebDriver driver = new ChromeDriver();
//		driver.get("https://artoftesting.com/samplesiteforselenium");
//		driver.manage().window().maximize();
//		
//		try {
//			driver.findElement(By.name("firstName")).sendKeys("ABC");
//			//driver.findElement(By.xpath("//input[@id='male']")).click();
//			Actions act = new Actions(driver);
//
//			//Double click on element
//			WebElement ele = driver.findElement(By.xpath("//button[@id='dblClkBtn']")); 
//			act.doubleClick(ele).perform();
//			Alert alert = driver.switchTo().alert();
//			alert.accept();
//			//driver.findElement(By.xpath("button[@id='dblClkBtn']"));
//	
//			Thread.sleep(3000);
//		} catch (InterruptedException e) {
//			
//			e.printStackTrace();
//		}
//		
//		driver.close();		
//
//	}

}
