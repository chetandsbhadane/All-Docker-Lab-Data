//package demo.test;
//
//import org.openqa.selenium.By;
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.chrome.ChromeDriver;
//
//public class MaxTest {
//
//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//		
//			WebDriver driver = new ChromeDriver();
//			driver.get("http://127.0.0.1:5500/maxNo.html");
//			driver.manage().window().maximize();
//			
//			try {
//				driver.findElement(By.id("num1")).sendKeys("11");
//				driver.findElement(By.id("num2")).sendKeys("51");
//				driver.findElement(By.id("num3")).sendKeys("111");
//				
////				
//				driver.findElement(By.xpath("//button[@id='b1']")).click();
//				driver.findElement(By.xpath("//button[@id='b2']")).click();
//				Thread.sleep(6000);
//			} catch (InterruptedException e) {
//				
//				e.printStackTrace();
//			}
//			driver.close();		
//
//		}
//
//	}
//
//
